

<?php $__env->startSection('content'); ?>
<div class="p-6">
    <h2 class="text-2xl font-semibold mb-4 text-green-600">✅ Approved Withdraw Requests</h2>

    <?php echo $__env->make('admin.withdraw._table', ['withdraws' => $withdraws, 'type' => 'approved'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\mahbub\resources\views/admin/withdraw/approved.blade.php ENDPATH**/ ?>