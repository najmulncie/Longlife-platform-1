 <!-- আপনার যেই লেআউট সেটা দিন -->

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto mt-10 bg-white p-6 rounded-2xl shadow-lg">
    <h2 class="text-2xl font-semibold mb-6 text-center">প্রোফাইল আপডেট করুন</h2>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 px-4 py-2 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-4 flex flex-col items-center">
            <img src="<?php echo e(Auth::user()->profile_photo ? asset('storage/' . Auth::user()->profile_photo) : asset('default-avatar.png')); ?>" class="w-24 h-24 rounded-full object-cover mb-2" alt="Profile Picture">
            <input type="file" name="profile_photo" class="text-sm text-gray-600">
        </div>

        <div class="mb-4">
            <label class="block font-medium">নাম</label>
            <input type="text" name="name" value="<?php echo e(Auth::user()->name); ?>" class="w-full border p-2 rounded" required>
        </div>

        <div class="mb-4">
            <label class="block font-medium">মোবাইল নম্বর</label>
            <input type="text" name="mobile" value="<?php echo e(Auth::user()->mobile); ?>" class="w-full border p-2 rounded" required>
        </div>

        <div class="mb-4">
            <label class="block font-medium">Gmail</label>
            <input type="email" name="email" value="<?php echo e(Auth::user()->email); ?>" class="w-full border p-2 rounded" required>
        </div>

        <div class="text-center">
            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">আপডেট করুন</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\mahbub\resources\views/user/profile.blade.php ENDPATH**/ ?>