

<?php $__env->startSection('content'); ?>
<div class="container mt-3">
    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-header d-flex justify-content-between align-items-center"
             style="background-color: #1F2937; padding: 20px 24px; border-bottom: 1px solid #e5e7eb;">
            <h4 class="mb-0 text-white fw-bold" style="font-size: 20px;">পেমেন্ট সেটিংস</h4>

            <a href="<?php echo e(route('payment-settings.create')); ?>" 
               class="btn btn-sm text-white shadow-sm"
               style="background-color: #3B82F6; padding: 8px 18px; border-radius: 6px;">
                নতুন যোগ করুন
            </a>
        </div>

        <div class="card-body px-3 pt-2 pb-0">
            <div class="table-responsive">
                <table class="table table-bordered align-middle text-center mb-0" style="font-size: 14.5px;">
                    <thead class="table-light">
                        <tr class="text-secondary">
                            <th class="py-2">মেথড</th>
                            <th class="py-2">নাম্বার</th>
                            <th class="py-2">ডিসক্রিপশন</th>
                            <th class="py-2">একশন</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="py-2"><?php echo e(ucfirst($setting->method)); ?></td>
                            <td class="py-2"><?php echo e($setting->number); ?></td>
                            <td class="py-2"><?php echo e($setting->description); ?></td>
                            <td class="py-2">
                                <div class="d-flex justify-content-center gap-2 flex-wrap">
                                    <a href="<?php echo e(route('payment-settings.edit', $setting->id)); ?>"
                                       class="btn btn-sm btn-outline-primary px-3 py-1 shadow-sm"
                                       style="min-width: 80px;">
                                        Edit
                                    </a>
                                    <form action="<?php echo e(route('payment-settings.destroy', $setting->id)); ?>" method="POST" onsubmit="return confirm('আপনি কি নিশ্চিতভাবে ডিলিট করতে চান?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                                class="btn btn-sm btn-outline-danger px-3 py-1 shadow-sm"
                                                style="min-width: 80px;">
                                            Delete
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-muted py-4 text-center">
                                কোনো পেমেন্ট সেটিংস পাওয়া যায়নি।
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\mahbub\resources\views/admin/payment_settings/index.blade.php ENDPATH**/ ?>