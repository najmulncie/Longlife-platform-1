

<?php $__env->startSection('content'); ?>
<div class="max-w-lg mx-auto p-6 bg-white rounded-lg shadow-lg mt-10">
    <h2 class="text-3xl font-extrabold text-blue-800 mb-8 text-center">একাউন্ট একটিভ করুন</h2>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6 text-center">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('user.activate.submit')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        
        <div class="mb-6">
            <label for="paymentMethod" class="block text-gray-700 font-semibold mb-2">পেমেন্ট মাধ্যম</label>
            <select name="method" id="paymentMethod" onchange="updateDetails()" class="w-full px-4 py-3 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent">
                <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($method->method); ?>" <?php echo e(old('method') == $method->method ? 'selected' : ''); ?>>
                        <?php echo e(ucfirst($method->method)); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="payment-info bg-gray-50 border border-gray-200 rounded-md p-4 mb-6 shadow-sm hidden" id="info_<?php echo e($method->method); ?>">
                <div class="flex justify-between items-center mb-2">
                    <label class="font-semibold text-gray-700"><?php echo e(ucfirst($method->method)); ?> নাম্বার:</label>
                    <div class="flex items-center gap-3">
                        <span class="text-blue-700 font-mono text-lg"><?php echo e($method->number); ?></span>
                        <button type="button" onclick="copyToClipboard('<?php echo e($method->number); ?>')" class="text-blue-600 hover:text-blue-800 focus:outline-none" aria-label="Copy Number">
                            📋
                        </button>
                    </div>
                </div>
                <p class="text-gray-600 text-sm"><?php echo e($method->description); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <div class="mb-6">
            <label for="user_number" class="block text-gray-700 font-semibold mb-2">আপনার নাম্বার (যেখান থেকে টাকা পাঠিয়েছেন)</label>
            <input type="text" name="user_number" id="user_number" value="<?php echo e(old('user_number')); ?>" placeholder="আপনার নাম্বার লিখুন" required class="w-full px-4 py-3 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent">
            <?php $__errorArgs = ['user_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-6">
            <label for="transaction_id" class="block text-gray-700 font-semibold mb-2">ট্রানজেকশন আইডি</label>
            <input type="text" name="transaction_id" id="transaction_id" value="<?php echo e(old('transaction_id')); ?>" placeholder="ট্রানজেকশন আইডি লিখুন" required class="w-full px-4 py-3 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent">
            <?php $__errorArgs = ['transaction_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-8">
            <label for="screenshot" class="block text-gray-700 font-semibold mb-2">পেমেন্টের স্ক্রিনশট (ঐচ্ছিক)</label>
            <input type="file" name="screenshot" id="screenshot" accept="image/*" class="w-full px-4 py-3 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent">
            <?php $__errorArgs = ['screenshot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <button type="submit" class="w-full bg-blue-700 hover:bg-blue-800 text-white font-bold py-3 rounded-md transition duration-300 ease-in-out">
            সাবমিট করুন
        </button>
    </form>
</div>


<script>
function updateDetails() {
    const selected = document.getElementById('paymentMethod').value;
    document.querySelectorAll('.payment-info').forEach(el => el.classList.add('hidden'));
    const activeDiv = document.getElementById('info_' + selected);
    if (activeDiv) activeDiv.classList.remove('hidden');
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert('নাম্বার কপি হয়েছে!');
    });
}

document.addEventListener('DOMContentLoaded', updateDetails);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\mahbub\resources\views/user/activate.blade.php ENDPATH**/ ?>