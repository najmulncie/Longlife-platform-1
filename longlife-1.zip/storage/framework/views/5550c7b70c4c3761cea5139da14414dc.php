 


<!-- <?php if(session('success')): ?>
    <div id="popupMessage" class="fixed top-5 right-5 bg-green-500 text-white px-4 py-2 rounded shadow-lg z-50 animate__animated animate__fadeInDown">
        <?php echo e(session('success')); ?>

    </div>

    <script>
        // 3 সেকেন্ড পর popup hide হবে
        setTimeout(function() {
            var popup = document.getElementById('popupMessage');
            if (popup) {
                popup.style.display = 'none';
            }
        }, 3000); // 3000 milliseconds = 3 seconds
    </script>
<?php endif; ?> -->

<?php if(session('success')): ?>
    <div id="popupMessage" class="custom-popup">
        <?php echo e(session('success')); ?>

    </div>

    <style>
        .custom-popup {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #28a745;
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            z-index: 9999;
            animation: slideDown 0.5s ease, fadeOut 1s ease 2.5s forwards;
        }

        @keyframes slideDown {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        @keyframes fadeOut {
            to { opacity: 0; transform: translateY(-10px); }
        }
    </style>

    <script>
        setTimeout(function () {
            var popup = document.getElementById('popupMessage');
            if (popup) {
                popup.remove();
            }
        }, 3500); // Total 3.5 seconds
    </script>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>আপনার টার্গেট সমূহ</h2>

    <?php $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $target): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card my-3">
            <div class="card-body">
                <h4><?php echo e(ucfirst($target['type'])); ?> টার্গেট পূরণ করুন <?php echo e($target['reward']); ?> টাকা জিতুন</h4>
                <p>রেফার হয়েছে: <?php echo e($target['achieved']); ?> / <?php echo e($target['required']); ?></p>

                <div class="progress mb-2" style="height: 20px;">
                    <div class="progress-bar" role="progressbar" style="width: <?php echo e($target['progress']); ?>%;">
                        <?php echo e(number_format($target['progress'], 1)); ?>%
                    </div>
                </div>

                <?php if($target['time_left']): ?>
                    <p>সময় বাকি: <?php echo e(gmdate("H:i:s", $target['time_left'])); ?></p>
                <?php endif; ?>

                <?php if($target['can_claim']): ?>
                    <form action="<?php echo e(route('user.claimTarget', $target['type'])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-success">বোনাস ক্লেইম করুন</button>
                    </form>
                <?php else: ?>
                    <button class="btn btn-secondary" disabled>টার্গেট পূরণ করুন</button>
                <?php endif; ?>

            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\mahbub\resources\views/user/targets.blade.php ENDPATH**/ ?>