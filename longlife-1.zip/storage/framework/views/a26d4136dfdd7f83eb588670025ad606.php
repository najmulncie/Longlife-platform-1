

<?php $__env->startSection('content'); ?>
    <h2 class="text-xl font-bold mb-4">🎯 টার্গেট বোনাস নিয়ন্ত্রণ</h2>

    <?php $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $target): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="<?php echo e(route('admin.targets.update', $target->id)); ?>" method="POST" class="mb-4 p-4 bg-white rounded shadow">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <h3 class="capitalize font-semibold"><?php echo e($target->type); ?> Target</h3>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-2">
                <div>
                    <label class="block">Required Active Refs</label>
                    <input type="number" name="required_active_refs" value="<?php echo e($target->required_active_refs); ?>" class="w-full border px-2 py-1 rounded">
                </div>

                <div>
                    <label class="block">Reward Amount (BDT)</label>
                    <input type="number" name="reward_amount" value="<?php echo e($target->reward_amount); ?>" class="w-full border px-2 py-1 rounded">
                </div>

                <div class="flex items-center mt-6">
                    <input type="checkbox" name="is_active" <?php echo e($target->is_active ? 'checked' : ''); ?> class="mr-2">
                    <span>Active</span>
                </div>
            </div>

            <button type="submit" class="mt-3 bg-blue-600 text-white px-4 py-2 rounded">Update</button>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\mahbub\resources\views/admin/targets/index.blade.php ENDPATH**/ ?>