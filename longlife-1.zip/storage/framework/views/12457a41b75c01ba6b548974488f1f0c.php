

<?php $__env->startSection('content'); ?>
<h2 class="text-xl font-bold mb-4">Inactive ইউজারগণ</h2>

<?php if($inactiveUsers->count()): ?>
<table class="w-full table-auto border-collapse border border-gray-300 rounded shadow">
    <thead class="bg-gray-200">
        <tr>
            <th class="border border-gray-300 px-4 py-2">ID</th>
            <th class="border border-gray-300 px-4 py-2">নাম</th>
            <th class="border border-gray-300 px-4 py-2">ইমেইল</th>
            <th class="border border-gray-300 px-4 py-2">মোবাইল</th>
            <th class="border border-gray-300 px-4 py-2">স্ট্যাটাস</th>
            <th class="border border-gray-300 px-4 py-2">অ্যাকশন</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $inactiveUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="hover:bg-gray-50">
            <td class="border border-gray-300 px-4 py-2"><?php echo e($user->id); ?></td>
            <td class="border border-gray-300 px-4 py-2"><?php echo e($user->name); ?></td>
            <td class="border border-gray-300 px-4 py-2"><?php echo e($user->email); ?></td>
            <td class="border border-gray-300 px-4 py-2"><?php echo e($user->mobile); ?></td>
            <td class="border border-gray-300 px-4 py-2 text-yellow-600 font-bold">Inactive</td>
            <td class="border border-gray-300 px-4 py-2">
                <form method="POST" action="<?php echo e(route('admin.users.update', $user->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="is_active" value="1">
                    <button type="submit" class="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded shadow">
                        Activate
                    </button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php else: ?>
<p class="text-gray-600">কোনো Inactive ইউজার নেই।</p>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\mahbub\resources\views/admin/users/inactive.blade.php ENDPATH**/ ?>