

<?php $__env->startSection('content'); ?>
<div class="p-6 max-w-xl mx-auto">
    <h1 class="text-2xl font-bold mb-4">লেভেল এডিট করুন</h1>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 text-red-700 p-3 rounded mb-4">
            <ul class="list-disc pl-5">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.leadership-levels.update', $leadershipLevel->id)); ?>" method="POST" class="space-y-4">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div>
            <label class="block font-medium">লেভেল নাম</label>
            <input type="text" name="name" value="<?php echo e($leadershipLevel->name); ?>" class="w-full border p-2 rounded" required>
        </div>

        <div>
            <label class="block font-medium">পুরস্কার (৳)</label>
            <input type="number" name="reward_amount" value="<?php echo e($leadershipLevel->reward_amount); ?>" class="w-full border p-2 rounded" required>
        </div>

        <div>
            <label class="block font-medium">টার্গেট কতজন</label>
            <input type="number" name="target_count" value="<?php echo e($leadershipLevel->target_count); ?>" class="w-full border p-2 rounded" required>
        </div>

        <div>
            <label class="block font-medium">টার্গেট টাইপ</label>
            <select name="target_type" class="w-full border p-2 rounded" required>
                <option value="direct" <?php echo e($leadershipLevel->target_type == 'direct' ? 'selected' : ''); ?>>ডিরেক্ট রেফার</option>
                <option value="level_1" <?php echo e($leadershipLevel->target_type == 'level_1' ? 'selected' : ''); ?>>১ম লেভেল অর্জনকারী</option>
                <option value="level_2" <?php echo e($leadershipLevel->target_type == 'level_2' ? 'selected' : ''); ?>>২য় লেভেল অর্জনকারী</option>
                <option value="level_3" <?php echo e($leadershipLevel->target_type == 'level_3' ? 'selected' : ''); ?>>৩য় লেভেল অর্জনকারী</option>
            </select>
        </div>

        <div>
            <label class="block font-medium">লেভেল নাম্বার</label>
            <input type="number" name="level_number" value="<?php echo e($leadershipLevel->level_number); ?>" class="w-full border p-2 rounded" required>
        </div>

        <div class="flex justify-end">
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">আপডেট করুন</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\mahbub\resources\views/admin/leadership_levels/edit.blade.php ENDPATH**/ ?>