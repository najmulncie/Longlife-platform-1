 

<?php $__env->startSection('content'); ?>
<div class="max-w-xl mx-auto p-6 bg-white rounded shadow mt-10">
    <h2 class="text-2xl font-bold mb-4">Fixed Commission Settings (10 Generation)</h2>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 p-3 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('admin.fixedCommissions.update')); ?>">
        <?php echo csrf_field(); ?>
        <?php for($i = 1; $i <= 10; $i++): ?>
            <div class="mb-4">
                <label class="block font-semibold mb-1">Generation <?php echo e($i); ?> Commission (৳)</label>
                <input type="number" name="amounts[<?php echo e($i); ?>]" step="0.01"
                    value="<?php echo e($commissions->firstWhere('generation', $i)->amount ?? 0); ?>"
                    class="w-full border rounded p-2">
            </div>
        <?php endfor; ?>

        <button type="submit" class="bg-blue-600 text-white font-bold py-2 px-4 rounded">
            Save Settings
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\mahbub\resources\views/admin/fixed_commissions.blade.php ENDPATH**/ ?>