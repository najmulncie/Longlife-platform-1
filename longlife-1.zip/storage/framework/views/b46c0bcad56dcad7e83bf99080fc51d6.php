

<?php $__env->startSection('content'); ?>
<div class="bg-white p-6 rounded-lg shadow-md">
    <h2 class="text-2xl font-semibold text-gray-800 mb-4">✅ অ্যাক্টিভ ইউজারগণ</h2>

    <?php if($activeUsers->count()): ?>
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto border border-gray-300 rounded-lg overflow-hidden">
                <thead class="bg-gray-100 text-left text-sm font-semibold text-gray-700">
                    <tr>
                        <th class="px-4 py-3 border-b border-gray-300">ID</th>
                        <th class="px-4 py-3 border-b border-gray-300">নাম</th>
                        <th class="px-4 py-3 border-b border-gray-300">ইমেইল</th>
                        <th class="px-4 py-3 border-b border-gray-300">মোবাইল</th>
                        <th class="px-4 py-3 border-b border-gray-300">স্ট্যাটাস</th>
                        <th class="px-4 py-3 border-b border-gray-300">অ্যাকশন</th>
                    </tr>
                </thead>
                <tbody class="text-sm text-gray-700">
                    <?php $__currentLoopData = $activeUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-4 py-3 border-b border-gray-200"><?php echo e($user->id); ?></td>
                            <td class="px-4 py-3 border-b border-gray-200"><?php echo e($user->name); ?></td>
                            <td class="px-4 py-3 border-b border-gray-200"><?php echo e($user->email); ?></td>
                            <td class="px-4 py-3 border-b border-gray-200"><?php echo e($user->mobile); ?></td>
                            <td class="px-4 py-3 border-b border-gray-200 text-green-600 font-bold">Active</td>
                            <td class="px-4 py-3 border-b border-gray-200">
                                <form method="POST" action="<?php echo e(route('admin.users.ban', $user->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded shadow">
                                        ব্যান করুন
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="text-gray-600 mt-4">
            📭 কোনো অ্যাক্টিভ ইউজার পাওয়া যায়নি।
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\mahbub\resources\views/admin/users/active.blade.php ENDPATH**/ ?>