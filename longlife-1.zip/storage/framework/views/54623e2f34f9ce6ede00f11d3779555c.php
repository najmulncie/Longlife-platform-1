

<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <h2 class="mb-4 text-primary fw-bold">Commission Settings</h2>

    <?php if(session('success')): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4" role="alert">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>


    <form method="POST" action="<?php echo e(route('admin.commissions.update')); ?>">
        <?php echo csrf_field(); ?>

        <div class="row g-3">
            <?php for($i = 1; $i <= 10; $i++): ?>
                <div class="col-md-6">
                    <label for="level-<?php echo e($i); ?>" class="form-label">Level <?php echo e($i); ?> Commission (%)</label>
                    <input
                        type="number"
                        step="0.01"
                        min="0"
                        max="100"
                        id="level-<?php echo e($i); ?>"
                        name="percentages[<?php echo e($i); ?>]"
                        value="<?php echo e(old('percentages.'.$i, $settings->firstWhere('level', $i)->percentage ?? 0)); ?>"
                        class="form-control <?php $__errorArgs = ['percentages.'.$i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="Enter commission for level <?php echo e($i); ?>"
                    >
                    <?php $__errorArgs = ['percentages.'.$i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            <?php endfor; ?>
        </div>

        <div class="mt-4">
            <button type="submit" class="btn btn-success px-4">Update Commissions</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\mahbub\resources\views/admin/commissions/index.blade.php ENDPATH**/ ?>