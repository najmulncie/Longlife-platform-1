  

<?php $__env->startSection('content'); ?>
<div class="container">

    <h2>My Gmail Sales History</h2>

    <!-- Status filter buttons -->
    <div class="btn-group mb-4" role="group" aria-label="Status Filter">
        <?php
            $statuses = ['pending' => 'Pending', 'checked' => 'Checked', 'rejected' => 'Rejected', 'completed' => 'Completed'];
        ?>

        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('user.gmail-sales.history', $key)); ?>" 
               class="btn btn-sm <?php echo e($status == $key ? 'btn-primary' : 'btn-outline-primary'); ?>">
               <?php echo e($label); ?>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php if($gmailSales->count() > 0): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Gmail Address</th>
                    <th>Status</th>
                    <th>Created At</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $gmailSales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($sale->id); ?></td>
                        <td><?php echo e($sale->gmail); ?></td>
                        <td><?php echo e(ucfirst($sale->status)); ?></td>
                        <td><?php echo e($sale->created_at->format('d M Y, h:i A')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No Gmail sales found for <strong><?php echo e(ucfirst($status)); ?></strong> status.</p>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\mahbub\resources\views/user/gmail_sales_history.blade.php ENDPATH**/ ?>