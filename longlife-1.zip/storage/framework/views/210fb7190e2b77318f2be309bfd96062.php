

<?php $__env->startSection('content'); ?>
    <div class="bg-white shadow rounded-lg">
        <div class="bg-red-600 text-white text-xl font-semibold px-6 py-4 rounded-t-md">
            Rejected Activation Requests
        </div>

        <div class="p-6">
            <?php if($requests->count()): ?>
                <table class="w-full table-auto border-collapse">
                    <thead class="bg-gray-100">
                        <tr class="text-left text-sm font-medium text-gray-700">
                            <th class="px-4 py-2">#</th>
                            <th class="px-4 py-2">User</th>
                            <th class="px-4 py-2">Payment Method</th>
                            <th class="px-4 py-2">Payment Number</th>
                            <th class="px-4 py-2">Txn ID</th>
                            <th class="px-4 py-2">Rejected At</th>
                        </tr>
                    </thead>
                    <tbody class="text-sm text-gray-800">
                        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-t">
                                <td class="px-4 py-2"><?php echo e($loop->iteration); ?></td>
                                <td class="px-4 py-2"><?php echo e($request->user->name); ?></td>
                                <td class="px-4 py-2"><?php echo e($request->method); ?></td>
                                <td class="px-4 py-2"><?php echo e($request->user_number); ?></td>
                                <td class="px-4 py-2"><?php echo e($request->transaction_id); ?></td>
                                <td class="px-4 py-2"><?php echo e($request->updated_at->format('d M Y, h:i A')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-center text-gray-500 mt-4">No rejected requests found.</p>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\mahbub\resources\views/admin/activation_requests/rejected.blade.php ENDPATH**/ ?>