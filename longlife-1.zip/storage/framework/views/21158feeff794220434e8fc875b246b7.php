

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h4>Withdraw Configuration</h4>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    
    <form action="<?php echo e(route('admin.withdraw.method.store')); ?>" method="POST" class="mb-4">
        <?php echo csrf_field(); ?>
        <h5>Add Withdraw Method</h5>
        <input type="text" name="name" class="form-control mb-2" placeholder="e.g., bKash, Nagad" required>
        <button type="submit" class="btn btn-primary">Add Method</button>
    </form>

    
    <form action="<?php echo e(route('admin.withdraw.type.store')); ?>" method="POST" class="mb-4">
        <?php echo csrf_field(); ?>
        <h5>Add Withdraw Type</h5>
        <input type="text" name="name" class="form-control mb-2" placeholder="e.g., Personal, Agent" required>
        <button type="submit" class="btn btn-primary">Add Type</button>
    </form>

    
    <form action="<?php echo e(route('admin.withdraw.config.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <h5>Withdraw Settings</h5>
        <div class="form-group">
            <label>Minimum Amount</label>
            <input type="number" name="min" value="<?php echo e($min); ?>" class="form-control" required>
        </div>
        <div class="form-group mt-2">
            <label>Maximum Amount</label>
            <input type="number" name="max" value="<?php echo e($max); ?>" class="form-control" required>
        </div>
        <div class="form-group mt-2">
            <label>Charge (%)</label>
            <input type="number" name="charge" value="<?php echo e($charge); ?>" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success mt-3">Save Configuration</button>
    </form>

    
    <div class="mt-5">
        <h5>Current Methods</h5>
        <ul>
            <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($m->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    
    <div class="mt-3">
        <h5>Current Types</h5>
        <ul>
            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($t->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\mahbub\resources\views/admin/withdraw/settings.blade.php ENDPATH**/ ?>