

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow rounded-lg overflow-x-auto">
    <div class="bg-indigo-600 text-white text-xl font-semibold px-6 py-4 rounded-t-md">
        Pending Activation Requests
    </div>

    <div class="p-6">
        <?php if($requests->count()): ?>
            <table class="min-w-full table-auto text-sm text-left border-collapse">
                <thead class="bg-gray-100">
                    <tr class="text-gray-700 font-medium">
                        <th class="px-4 py-2">#</th>
                        <th class="px-4 py-2">User</th>
                        <th class="px-4 py-2">Method</th>
                        <th class="px-4 py-2">Number</th>
                        <th class="px-4 py-2">Txn ID</th>
                        <th class="px-4 py-2">Screenshot</th>
                        <th class="px-4 py-2 text-center">Actions</th>
                    </tr>
                </thead>
                <tbody class="text-gray-800">
                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-t">
                            <td class="px-4 py-2"><?php echo e($loop->iteration); ?></td>
                            <td class="px-4 py-2"><?php echo e($request->user->name); ?></td>
                            <td class="px-4 py-2 capitalize"><?php echo e($request->method); ?></td>
                            <td class="px-4 py-2"><?php echo e($request->user_number); ?></td>
                            <td class="px-4 py-2"><?php echo e($request->transaction_id); ?></td>
                            <td class="px-4 py-2">
                               
<?php if($request->screenshot): ?>
    <a href="<?php echo e(asset('uploads/activation_screenshots/' . $request->screenshot)); ?>" target="_blank">
        <img src="<?php echo e(asset('uploads/activation_screenshots/' . $request->screenshot)); ?>" alt="Screenshot" class="h-12 w-auto rounded border" />
    </a>
<?php else: ?>
    <span class="text-gray-400 italic">No Image</span>
<?php endif; ?>

                            </td>
                            <td class="px-4 py-2 text-center space-x-2">
                                <form method="POST" action="<?php echo e(route('admin.activation.approve', $request->id)); ?>" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <button class="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded text-xs">Approve</button>
                                </form>
                                <form method="POST" action="<?php echo e(route('admin.activation.reject', $request->id)); ?>" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <button class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-xs">Reject</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="text-center text-gray-500 mt-4">No pending requests found.</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\mahbub\resources\views/admin/activation_requests/pending.blade.php ENDPATH**/ ?>