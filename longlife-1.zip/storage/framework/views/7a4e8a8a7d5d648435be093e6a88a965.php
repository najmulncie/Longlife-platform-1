

<?php $__env->startSection('content'); ?>
<div class="p-6">
    <h2 class="text-2xl font-semibold mb-4 text-yellow-600">🕐 Pending Withdraw Requests</h2>

    <?php echo $__env->make('admin.withdraw._table', ['withdraws' => $withdraws, 'type' => 'pending'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\mahbub\resources\views/admin/withdraw/pending.blade.php ENDPATH**/ ?>